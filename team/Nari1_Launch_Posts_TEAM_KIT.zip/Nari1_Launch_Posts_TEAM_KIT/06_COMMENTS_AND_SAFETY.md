# Comments and safety

Nari 1 is a women's health app. People may write personal things. Be warm, short and careful. When in doubt, do not answer: tell Megh.

## Answering comments

**Do**

- Say thank you. Keep it to one or two lines.
- Only repeat what the post already says.
- Tell people the daily check-in and the Chi score are free (that is on the posts).
- Send questions you cannot answer to Megh.

**Never**

- **No medical advice.** Not even a small tip. No "you should", no "try", no talk about symptoms, tablets, tests or cycles.
- **No diagnosing.** Never say what someone "has" or what a symptom "means".
- **No prices** other than the published ones: the ₹499 call (only after post 10 is live) and "free" for the daily check-in and the Chi score.
- **No promises.** Never promise a launch date, a feature, a result or a reply.
- **Never say the ₹499 call is with a doctor.** It is with a Nari health coach or counsellor.
- No arguing. No emoji storms. No copying other people's comments.

**Safe replies you can use word for word** (Megh must approve this list before the first use; until then, tell Megh and wait):

- "Thank you. We are glad it speaks to you."
- "Thank you for telling us. We have passed it on to the team."
- "Good question. We will come back to you here." (then tell Megh the same day)

## If someone sounds in distress (in a comment or a message)

Examples: she says she wants to hurt herself, she cannot go on, she is in danger.

1. **Reply once, with the helpline lines below and nothing else.** Copy them exactly. Do not write your own words, do not add advice, do not add emoji.
2. **Tell Megh straight away** (call or message, do not wait for a daily check-in). Send a screenshot.
3. Do not delete the comment or message. Do not keep chatting. Do not promise anything.

These lines are copied character for character from the app's own crisis list (`apps/mobile/lib/core/utils/constants/crisis_helplines.dart`, the list every crisis screen in the app shows):

| Name | Number | When |
|---|---|---|
| Tele MANAS | 1800-89-14416 | 24/7 MoHFW |
| Tele MANAS | 14416 | 24/7 MoHFW short code |
| Vandrevala Foundation | +91 9999 666 555 | 24/7/365 multilingual |
| iCALL (TISS) | 022-25521111 | Mon-Sat 8am-10pm |
| AASRA | 022-27546669 | 24/7 English/Hindi |

Paste block:

```
Tele MANAS: 1800-89-14416 (24/7 MoHFW)
Tele MANAS: 14416 (24/7 MoHFW short code)
Vandrevala Foundation: +91 9999 666 555 (24/7/365 multilingual)
iCALL (TISS): 022-25521111 (Mon-Sat 8am-10pm)
AASRA: 022-27546669 (24/7 English/Hindi)
```

## Spam and abuse

- **Spam** (ads, links, bots): hide or delete it. No reply.
- **Abuse** (insults, harassment): take a screenshot first, then hide the comment. Do not reply. If it continues, block the account and tell Megh.
- **Threats:** screenshot, do not reply, tell Megh straight away.
- **A complaint about the app or a post:** do not defend, do not explain. Screenshot and tell Megh the same day.

## The stop rule

Stop posting and tell Megh **before the next post** if any of these happens:

- Comments complain about a post, or several people react badly to the same thing.
- A platform sends a warning, removes a post, or limits the account.
- Reach on a post is much lower than on the post before it (as a first rule: less than half). This number is a default to review after week one, not a result from our own data.
- Anything in a comment or message that you did not expect or do not understand.

Megh decides whether the series continues.
