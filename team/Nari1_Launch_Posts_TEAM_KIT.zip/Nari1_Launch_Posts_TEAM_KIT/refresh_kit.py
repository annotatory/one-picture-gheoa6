#!/usr/bin/env python3 -I
"""Regenerates the live files of the Nari 1 team kit from _kit/kit_data.json and _kit/kit_state.json, then re-makes the zip.

One command per change, for example:
    python3 -I refresh_kit.py --clear 10            # an owner cleared everything on post 10 (K4, L5, N1)
    python3 -I refresh_kit.py --clear K4 L5         # clear single questions by their ID
    python3 -I refresh_kit.py --clear start         # the two start gates: M1 M2 (waitlist page live, grid test passed)
    python3 -I refresh_kit.py --reject L2           # an owner said NO: the post stays STOP and Megh decides
    python3 -I refresh_kit.py --answer M5 "8 November"    # an answer with a value (launch date for the post 12 caption), also clears it
    python3 -I refresh_kit.py --answer R1 18        # measured check-in time in seconds, also clears it
    python3 -I refresh_kit.py --answer N1 "YES, ..."   # a yes with the owner's note: clears it, the note shows in 05_HELD_INDEX and the master tracker
    python3 -I refresh_kit.py --reopen L2           # undo
    python3 -I refresh_kit.py --posted 4            # post 4 is confirmed live (the log has it)
    python3 -I refresh_kit.py --start-date 2026-11-12   # the planned launch day: all 12 posts on Instagram, post 1 on Facebook, LinkedIn and X (default 2026-10-28)

Cadence (Megh, 28 Oct 2026, "lets do all the posts at once and then Keep it paced"): all 12 posts on ONE launch day, in order 1 to 12,
so the profile grid forms the picture at once. 28 Oct night: Instagram all 12 at once; LinkedIn/X/Facebook paced one a day (post n on day n,
day 1 = the launch day). The launch day waits until every post is cleared: while any post is held, every post says STOP.
    python3 -I refresh_kit.py --team-lead "Name, +91 ..."   # who posts and owns the logs; shown in 00_START_HERE
    python3 -I refresh_kit.py --window "8:00 to 9:00 pm India time"   # posting window (default 7:30 to 9:30 pm); every doc and card follows
    python3 -I refresh_kit.py --contact "Megh: +91 ..."     # shown in 00_START_HERE and the STATUS cards
    python3 -I refresh_kit.py --accounts "Instagram: @..; LinkedIn page: ..; Facebook page: ..; X: @.."
    python3 -I refresh_kit.py --status              # print today's statuses only

It rewrites: status in every post folder name, STATUS.txt, caption.txt, caption_for_X.txt, alt_text.txt, 01_POSTING_CALENDAR, 05_HELD_INDEX and every .html, and the zip next to this folder.
It never touches pictures. Held sentences are never written into a caption.txt until the question that holds them is cleared.
"""
import argparse, csv, datetime, html, json, os, pathlib, re, sys, zipfile

ROOT = pathlib.Path(__file__).resolve().parent
KIT = ROOT / '_kit'
DATA = json.loads((KIT / 'kit_data.json').read_text(encoding='utf-8'))
STATE_FILE = KIT / 'kit_state.json'
STATE = json.loads(STATE_FILE.read_text(encoding='utf-8')) if STATE_FILE.exists() else {'cleared': [], 'rejected': [], 'answers': {}}
STATE.setdefault('start_date', DATA.get('start_date'))
ITEMS = {i['id']: i for i in DATA['items']}
OWNER = {o['key']: o for o in DATA['owners']}
POSTS = {p['n']: p for p in DATA['posts']}
DEFAULT_WINDOW = '7:30 to 9:30 pm India time'


def first_post(it):
    m = re.match(r'\d+', str(it['post']))
    return int(m.group()) if m else 1


def stops(it, n):
    k, b = it['blocks']['kind'], it['blocks'].get('post')
    return k == 'series' or (k == 'from' and n >= b) or (k == 'post' and n == b)


def is_open(i):
    return i not in STATE['cleared']


def blocks_text(it):
    b = it['blocks']
    return {'series': 'Everything: no post goes out', 'from': f"Post {b.get('post')} and every post after it, so the whole launch day (all 12 go out together on Instagram)",
            'post': f"Post {b.get('post')}, so the whole launch day (all 12 go out together on Instagram)",
            'paid': f"The paid version of post {b.get('post')} only", 'none': 'Nothing: the post goes out with the fallback'}[b['kind']]


def blockers(n, gates=True):
    return [it for it in DATA['items'] if it['blocks']['kind'] in ('series', 'from', 'post') and stops(it, n) and is_open(it['id'])
            and (gates or it['blocks']['kind'] != 'series')]


def launch_blockers():
    # every open question that holds any of the 12 posts: all 12 go out together on Instagram, so each one holds the whole launch day
    out, seen = [], set()
    for m in range(1, 13):
        for it in blockers(m):
            if it['id'] not in seen:
                seen.add(it['id']); out.append(it)
    return out


def launch_text():
    lb = launch_blockers()
    if lb:
        return f"WAITING. All 12 posts go out together on Instagram on one day, in order 1 to 12. Nothing goes out, on any platform, until every post is cleared. Still open: {ids(lb)}."
    sd = STATE.get('start_date')
    return f"READY. Instagram: all 12 posts in one sitting, in order 1 to 12{(' (launch day planned ' + fmt(sd) + ')') if sd else ''}. Facebook, LinkedIn and X: post 1 on the launch day, then one a day to post 12."


def status(n, gates=True):
    # gates=True: what the team may do today (start gates, this post's questions, and the launch day: one held post holds all 12)
    # gates=False: this post on its own (its own questions only)
    if blockers(n, gates):
        return 'STOP-UNTIL'
    if gates and launch_blockers():
        return 'STOP-UNTIL'
    if n == 9 and is_open('K3'):
        return 'GO-WITH-FALLBACK'
    if n == 12 and is_open('M4'):
        return 'GO-WITH-FALLBACK'
    return 'GO'


def ids(items):
    return ', '.join(f"{i['id']} ({OWNER[i['owner']]['name']})" for i in items)


def window():
    return STATE.get('window') or DEFAULT_WINDOW


def packet_link(it):
    return f"05_HELD_INDEX_packets/{it['owner']}_packet.pdf"


def fmt(iso):
    return datetime.date.fromisoformat(iso).strftime('%a %d %b %Y').replace(' 0', ' ')


def dates_text():
    sd = STATE.get('start_date')
    if not sd:
        return 'The launch day is set when Megh says go.'
    return (f"**Dates.** Instagram: all 12 posts go out on one launch day, in order 1 to 12, so the profile grid forms the picture at once (Megh, 28 Oct 2026). Planned launch day: {fmt(sd)}. "
            f"Facebook, LinkedIn and X: one post a day, in order 1 to 12, starting on the launch day (post 1 on {fmt(sd)}, post 12 on {fmt(paced_date(12))}), so follower feeds there are not flooded (28 Oct 2026, night). "
            "The day waits until every post is cleared: if any post says STOP-UNTIL, nothing goes out, and the launch day moves to the first day all 12 are cleared (the Facebook, LinkedIn and X dates move with it). Posts after the 12 are paced; Megh sets that plan.")


def post_date(n):
    # Instagram: one launch day for all 12 posts (Megh, 28 Oct 2026); n is kept so every caller still asks per post
    sd = STATE.get('start_date')
    if not sd:
        return None
    return datetime.date.fromisoformat(sd).isoformat()


def paced_date(n):
    # Facebook, LinkedIn and X: one post a day, post 1 on the launch day, post n on day n (28 Oct 2026, night)
    sd = STATE.get('start_date')
    if not sd:
        return None
    return (datetime.date.fromisoformat(sd) + datetime.timedelta(days=n - 1)).isoformat()


def gates_text():
    g = [i for i in DATA['items'] if i['blocks']['kind'] == 'series']
    open_g = [i for i in g if is_open(i['id'])]
    if open_g:
        return 'OPEN: ' + ', '.join(f"{i['id']} {i['name']}" for i in open_g) + '. Every post says STOP until they are cleared.'
    return 'CLEARED' + (f" on {STATE['gates_cleared_on']}" if STATE.get('gates_cleared_on') else '') + ' (waitlist page live on nari1.com, grid test passed).'


def first_job():
    g = [i for i in DATA['items'] if i['blocks']['kind'] == 'series']
    if any(is_open(i['id']) for i in g):
        return ("The start gates are still open (see the Right now box). Open **03_GRID_TEST** and do the test on the spare private account: post the 12 tiles by hand in order, take a screenshot, send it to Megh, and delete the spare account when Megh says JOINED. "
                "Nothing goes live on the real accounts until Megh says the test worked and the waitlist page is live. "
                "If the Right now box still has blanks for Megh's contact or the accounts, do not post: ask Megh to fill them. You post by hand from the phone app of each platform: no tool is connected to any account.")
    if launch_blockers():
        return ("The start gates are cleared: the waitlist page is live and the grid test is done, so **do not repeat the grid test**. The launch day still waits (see the Right now box): all 12 posts go out together on Instagram, so **do not post anything** until every row of **01_POSTING_CALENDAR** says GO or GO-FALLBACK. "
                "If the Right now box still has blanks for Megh's contact or the accounts, ask Megh to fill them. You post by hand from the phone app of each platform: no tool is connected to any account.")
    return ("The start gates are cleared: the waitlist page is live and the grid test is done, so **do not repeat the grid test**. Every post is cleared: on the launch day, follow **01_POSTING_CALENDAR** and post all 12 on Instagram in one sitting, in rounds (the Instagram feed for posts 1 to 12 first, then Stories), then post 1 on Facebook, LinkedIn and X; after that, one post a day on Facebook, LinkedIn and X, up to post 12. Read each post's STATUS.txt as you go. "
            "If the Right now box still has blanks for Megh's contact or the accounts, do not post: ask Megh to fill them. You post by hand from the phone app of each platform: no tool is connected to any account.")


def now_block():
    lp = STATE.get('last_posted')
    return ['## Right now', '', '| | |', '|---|---|',
            f"| Start gates | {gates_text()} |",
            f"| Launch day (all 12 on Instagram) | {launch_text()} |",
            f"| Last post confirmed live | {('post ' + str(lp)) if lp else 'none yet'} |",
            f"| Launch day (planned) | {fmt(STATE['start_date']) if STATE.get('start_date') else 'Megh sets it when he says go'} |",
            f"| Team lead (posts and owns the logs) | {STATE.get('team_lead') or 'Megh names the team lead and writes it here before you start'} |",
            f"| Posting window (default, a test) | {window()} |",
            f"| Megh's contact (the only person you ask) | {STATE.get('contact') or 'Ask Megh how he wants to be reached, and write it here before you start'} |",
            f"| Accounts to post from | {STATE.get('accounts') or 'Ask Megh which account to use for Instagram, Facebook (personal profile or Page), LinkedIn (profile or company page) and X, and write them here before you start'} |", '']


PLATFORMS = [('INSTAGRAM FEED (carousel)', 'INSTAGRAM_feed_4x5', 'Instagram feed', 'caption.txt', 'alt_text.txt: paste the line under PICTURE 1 on picture 1, and so on'),
             ('INSTAGRAM STORY', 'INSTAGRAM_story_9x16', 'Instagram Story', None, 'none needed'),
             ('FACEBOOK (square)', 'LINKEDIN_FACEBOOK_1x1', 'Facebook', 'caption.txt', 'alt_text.txt if the app offers it (skip if not)'),
             ('LINKEDIN (square)', 'LINKEDIN_FACEBOOK_1x1', 'LinkedIn', 'caption.txt', 'alt_text.txt if the app offers it (skip if not)'),
             ('X (wide)', 'X_wide_16x9', 'X', 'caption_for_X.txt', 'the "Story and wide picture" line of alt_text.txt if the app offers it')]


def cards(n, d):
    fb = n == 9 and status(9) != 'GO'
    when, paced = post_date(n), paced_date(n)
    L = ['', f"PLATFORM CARDS, in the posting window {window()} (the default and a test). Cards 1 and 2 (Instagram) on the launch day{(' (' + when + ')') if when else ''}, in rounds across all 12 posts: card 1 (Instagram feed) for posts 1 to 12 first, in order, so the grid forms at once; then card 2 for posts 1 to 12. "
         f"Cards 3, 4 and 5 (Facebook, LinkedIn, X) for this post on day {n}{(' (' + paced + ')') if paced else ''}: one post a day there, " + ('after the Instagram rounds on the launch day.' if n == 1 else f'only after post {n - 1} is live there.'),
         f"Account for each: {STATE.get('accounts') or 'ask Megh (see the Right now box in 00_START_HERE)'}.", f"Megh: {STATE.get('contact') or 'ask him how to reach him'}"]
    for k, (title, folder, plat, cap, alt) in enumerate(PLATFORMS, 1):
        sub_d = d / (folder + ('__FALLBACK' if fb else ''))
        files = sorted(f.name for f in sub_d.iterdir() if f.is_file()) if sub_d.exists() else []
        issue = 'FALLBACK' if (fb or (n == 12 and status(12) == 'GO-WITH-FALLBACK')) else 'none'
        link = 'story no link' if plat == 'Instagram Story' else '<link>'
        on = when if folder.startswith('INSTAGRAM') else paced
        L += ['', f"{k}. {title}", '   Pick these files in this order:'] + [f"      {sub_d.name}/{f}" for f in files]
        L += [f"   Caption: {cap or 'none (a Story has no caption)'}", f"   Alt text: {alt}",
              f"   Then add this row to 07_POSTED_LOG.csv: {n},{plat},{(on + ' ') if on else ''}HH:MM,{link},<your name>,{issue}"]
    L += ['', f"24 HOURS AFTER: add this platform's numbers for post {n} to 08_ENGAGEMENT_LOG.csv (see 02_HOW_TO_POST, The engagement log)."]
    return L


def later_posts_waiting(n):
    # every later post is waiting behind this one while it is held (the profile picture only forms in order)
    return list(range(n + 1, 13))


def caption_for(n):
    p = POSTS[n]
    own = blockers(n, gates=False)
    if own:
        return None, own
    c = p['caption']
    if n == 3 and not is_open('K1') and not is_open('H1') and 'caption_k1' in p:
        c = p['caption_k1']
    if n == 4 and 'R1' in STATE['answers'] and re.search(r'\d', str(STATE['answers']['R1'])):
        t = re.search(r'\d+', str(STATE['answers']['R1'])).group()
        c = c.replace('Pick one word.', f'Pick one word. About {t} seconds.')
    if n == 12 and 'M5' in STATE['answers'] and str(STATE['answers']['M5']).strip().lower() not in ('', 'no', 'none', '-'):
        c = c.replace('\nLink in bio.', f"\nLaunch date: {STATE['answers']['M5']}.\nLink in bio.", 1)
    return c, []


def short_for_x(c):
    out = []
    for line in c.split('\n'):
        if len('\n'.join(out + [line])) <= 270:
            out.append(line)
    return '\n'.join(out)


def withheld_text(n, own):
    return (f"NOT RELEASED. Do not post.\nPost {n} is waiting on: {ids(own)}.\n"
            "This file is replaced by the real caption when those questions are cleared (Megh runs the refresh).\n")


def files_block(d, n):
    use_fb = n == 9 and status(9) != 'GO'
    L = []
    for sub in sorted(x for x in d.iterdir() if x.is_dir()):
        if sub.name == 'PAID_SAFE':
            continue
        fb = sub.name.endswith('__FALLBACK')
        if fb != use_fb and n == 9:
            continue
        L += [f"  {sub.name}/{f.name}" for f in sorted(sub.iterdir()) if f.is_file()]
    return L


def status_text(n, d):
    p = POSTS[n]
    today, after = status(n), status(n, gates=False)
    gates = [i for i in blockers(n) if i['blocks']['kind'] == 'series']
    own = blockers(n, gates=False)
    attached = [i for i in DATA['items'] if first_post(i) == n and i['blocks']['kind'] in ('none', 'paid') and not i.get('fyi')]
    when, paced = post_date(n), paced_date(n)
    L = [f"POST {n}: {p['title']}  ({(f'Instagram: launch day, {n} of 12, {when}; Facebook, LinkedIn and X: day {n}, {paced}') if when else p['label']})", f"What goes on the picture: {p['line']}", '',
         f"STATUS TODAY: {today}", f"This post on its own (start gates and the other 11 posts aside): {after}",
         f"Start gates: {gates_text()}", f"Launch day: {launch_text()}",
         f"Last post confirmed live: {('post ' + str(STATE['last_posted'])) if STATE.get('last_posted') else 'none yet'} (post n only after post n-1 is live, on every platform).", '']
    if gates:
        L += [f"Start gates still open: {ids(gates)}. Nothing goes out until they are cleared (see 01_POSTING_CALENDAR and 03_GRID_TEST)."]
    if today == 'STOP-UNTIL' and not gates and not own:
        L += ["This post is ready on its own, but nothing goes out until the launch day is ready (see Launch day above): all 12 go out together on Instagram."]
    if own:
        L += ['WAITING ON:'] + [f"  - {i['id']} ({OWNER[i['owner']]['name']}{'; sign-off reported by Megh 28 Oct, scope unconfirmed, still held' if i.get('reported') else ''}): {i['q']}\n      If the answer is NO: {i['no']}\n      Blocks: {blocks_text(i)}.\n      Packet (Megh holds it): {packet_link(i)}" for i in own]
        L += ['', f"POSTS THAT WAIT BEHIND THIS ONE: {', '.join(map(str, later_posts_waiting(n))) or 'none'} (the profile picture only forms in order). The whole launch day waits too: all 12 go out together on Instagram."]
    if today == 'GO-WITH-FALLBACK' or (n == 9 and after == 'GO-WITH-FALLBACK'):
        L += ['', 'USE THE FALLBACK FILES for post 9: the folders ending __FALLBACK (slide 1 is the normal picture, slides 2 and 3 are the paid-safe ones without the cycle sentence).',
              'Do NOT use the plain INSTAGRAM_feed_4x5, LINKEDIN_FACEBOOK_1x1, story or wide folders. Write FALLBACK in the POSTED_LOG issue column.',
              'Post 9 is for women 18 and over only: if the app offers an age limit for the post, set 18+; if it does not, tell Megh before posting.']
    elif n == 9:
        L += ['', 'Post 9 is for women 18 and over only: if the app offers an age limit for the post, set 18+; if it does not, tell Megh before posting.']
    if n == 12 and today == 'GO-WITH-FALLBACK':
        L += ['', 'POST 12 GOES OUT WITH THE FALLBACK (the post does not wait for the store links). Use the normal files and caption.txt exactly. The bio link stays on the waitlist page until Megh tells you the store links are live.',
              'Do not add a store link, a date or a time anywhere unless it is already in caption.txt. Write FALLBACK in the POSTED_LOG issue column.']
    if n == 2:
        L += ['', 'Organic only. The paid version of post 2 is not cleared (L1).'] if is_open('L1') else []
    open_att = [i for i in attached if is_open(i['id'])]
    if open_att:
        L += ['', 'Also open, but they do NOT stop this post (it goes out with the prepared fallback):'] + [f"  - {i['id']} ({OWNER[i['owner']]['name']}): {i['name']}. If still open: {i['silence']}" for i in open_att]
    if today != 'STOP-UNTIL':
        L += cards(n, d)
    else:
        L += ['', 'No platform cards while the status is STOP-UNTIL. They appear here when the status becomes GO.']
    return '\n'.join(L) + '\n'


def alt_text_for(n):
    p = POSTS[n]
    own = blockers(n, gates=False)
    if own:
        return withheld_text(n, own).replace('This file is replaced by the real caption', 'This file is replaced by the real alt text')
    if 'fallback' in p and is_open('K3'):  # the organic slide 3 shows the held cycle sentence: only the fallback lines are given
        L = ['ALT TEXT for post 9, fallback pictures. One block per picture: paste ONLY the line under the label, not the label. Do not change a word. If a box cuts a line off, paste what fits and tell Megh. Stories need no alt text.', '']
        for k, a in enumerate(p['fallback']['alt'], 1):
            L += [f"PICTURE {k} of {len(p['fallback']['alt'])}", a, '']
        L += ['STORY AND WIDE PICTURE (X only; Stories need none)', p['fallback']['alt_compose']]
        return '\n'.join(L) + '\n'
    L = ['ALT TEXT. One block per picture: paste ONLY the line under the label, not the label. Do not change a word. If a box cuts a line off, paste what fits and tell Megh. Stories need no alt text.', '']
    for k, a in enumerate(p['alt'], 1):
        L += [f"PICTURE {k} of {len(p['alt'])}", a, '']
    L += ['STORY AND WIDE PICTURE (X only; Stories need none)', p['alt_compose']]
    if 'fallback' in p:
        L += ['', 'IF YOU USE THE FALLBACK FILES (post 9) paste these instead:']
        for k, a in enumerate(p['fallback']['alt'], 1):
            L += [f"FALLBACK PICTURE {k} of {len(p['fallback']['alt'])}", a, '']
        L += ['FALLBACK STORY AND WIDE PICTURE', p['fallback']['alt_compose']]
    return '\n'.join(L) + '\n'


# ---------- markdown to html (small, enough for this kit)
CSS = """:root{--bg:#F4F1EB;--surface:#FFFEFB;--subtle:#ECE9E2;--line:#DDD8CF;--fg:#18151F;--t2:#67616D;--accent:#4B46D8;--warntint:#F6E6CB;--oktint:#D9EBE5}
@media (prefers-color-scheme:dark){:root{--bg:#121018;--surface:#1C1923;--subtle:#24202B;--line:#332F3C;--fg:#F4F1EB;--t2:#B8B1BC;--accent:#8E8AF0;--warntint:#33270F;--oktint:#16302A;color-scheme:dark}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--fg);font-family:system-ui,-apple-system,'Segoe UI',sans-serif;font-size:16px;line-height:1.55;padding-left:max(16px,env(safe-area-inset-left,0px));padding-right:max(16px,env(safe-area-inset-right,0px))}
.wrap{max-width:860px;margin:0 auto;padding-block:24px 64px}h1{font-size:1.9rem;line-height:1.1;margin:0 0 12px}h2{font-size:1.3rem;margin:30px 0 8px}h3{font-size:1.05rem;margin:22px 0 6px}p{margin:0 0 12px;max-width:70ch}a{color:var(--accent)}
pre{white-space:pre-wrap;word-wrap:break-word;background:var(--subtle);border-radius:12px;padding:12px 14px;font:inherit;font-size:.95rem}code{background:var(--subtle);border-radius:6px;padding:1px 6px;font-size:.92em;overflow-wrap:anywhere}p,li,td{overflow-wrap:break-word}
.table{overflow-x:auto;margin:8px 0 16px}table{border-collapse:collapse;min-width:100%;font-size:.9rem;background:var(--surface)}th,td{text-align:left;padding:8px 10px;border-bottom:1px solid var(--line);vertical-align:top}th{font-size:.78rem;color:var(--t2)}
ul,ol{padding-left:22px;max-width:70ch}li{margin-bottom:6px}.nav{font-size:.85rem;color:var(--t2);margin-bottom:10px}.nav a{color:inherit}"""


def inline(t):
    t = html.escape(t, quote=False)
    t = re.sub(r'`([^`]+)`', r'<code>\1</code>', t)
    t = re.sub(r'\*\*([^*]+)\*\*', r'<b>\1</b>', t)
    t = re.sub(r'\[([^\]]+)\]\((https?://[^)]+)\)', r'<a href="\2">\1</a>', t)
    return t


def md_to_html(md, title):
    out, i, lines = [], 0, md.split('\n')
    while i < len(lines):
        l = lines[i]
        if l.startswith('```'):
            j = i + 1; buf = []
            while j < len(lines) and not lines[j].startswith('```'): buf.append(lines[j]); j += 1
            out.append('<pre>' + html.escape('\n'.join(buf)) + '</pre>'); i = j + 1; continue
        if l.startswith('|') and i + 1 < len(lines) and re.match(r'^\|[\s:|-]+\|$', lines[i + 1]):
            head = [c.strip() for c in l.strip('|').split('|')]; rows = []; j = i + 2
            while j < len(lines) and lines[j].startswith('|'):
                rows.append([c.strip() for c in lines[j].strip().strip('|').split('|')]); j += 1
            out.append('<div class="table"><table><thead><tr>' + ''.join(f'<th>{inline(c)}</th>' for c in head) + '</tr></thead><tbody>'
                       + ''.join('<tr>' + ''.join(f'<td>{inline(c)}</td>' for c in r) + '</tr>' for r in rows) + '</tbody></table></div>'); i = j; continue
        m = re.match(r'^(#{1,3}) (.*)', l)
        if m: out.append(f'<h{len(m.group(1))}>{inline(m.group(2))}</h{len(m.group(1))}>'); i += 1; continue
        if re.match(r'^\d+\. ', l):
            items = []
            while i < len(lines) and re.match(r'^\d+\. ', lines[i]): items.append(re.sub(r'^\d+\. ', '', lines[i])); i += 1
            out.append('<ol>' + ''.join(f'<li>{inline(x)}</li>' for x in items) + '</ol>'); continue
        if l.startswith('- '):
            items = []
            while i < len(lines) and lines[i].startswith('- '): items.append(lines[i][2:]); i += 1
            out.append('<ul>' + ''.join(f'<li>{inline(x)}</li>' for x in items) + '</ul>'); continue
        if l.strip() == '': i += 1; continue
        buf = [l]; i += 1
        while i < len(lines) and lines[i].strip() and not re.match(r'^(#|\||```|- |\d+\. )', lines[i]): buf.append(lines[i]); i += 1
        out.append('<p>' + inline(' '.join(buf)) + '</p>')
    nav = '<div class="nav"><a href="00_START_HERE.html">Start here</a> · <a href="01_POSTING_CALENDAR.html">Calendar</a> · <a href="02_HOW_TO_POST.html">How to post</a> · <a href="03_GRID_TEST.html">Grid test</a> · <a href="05_HELD_INDEX.html">Held index</a> · <a href="06_COMMENTS_AND_SAFETY.html">Comments and safety</a></div>'
    return (f'<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">'
            f'<meta name="robots" content="noindex,nofollow,noarchive"><title>{html.escape(title)}</title><style>{CSS}</style></head><body><div class="wrap">{nav}{"".join(out)}</div></body></html>')


def write_doc(name, md):
    (ROOT / f'{name}.md').write_text(md, encoding='utf-8')
    (ROOT / f'{name}.html').write_text(md_to_html(md, name.split('_', 1)[1].replace('_', ' ').title() + ' · Nari 1 launch posts'), encoding='utf-8')


# ---------- calendar, held index
def time_row():
    return f"{window()}, feed first"


def calendar():
    rows = []
    for n in range(1, 13):
        p = POSTS[n]; t, a = status(n), status(n, gates=False)
        bl = blockers(n)
        rest = [i for i in launch_blockers() if i['id'] not in {b['id'] for b in bl}]
        unlock = (ids(bl) if bl else 'nothing of its own') + (f"; the launch day also waits on {ids(rest)}" if rest else '') if (bl or rest) else 'nothing: cleared'
        rows.append([str(n), (f"Instagram: launch day, {n} of 12, {fmt(post_date(n))}; Facebook, LinkedIn and X: day {n}, {fmt(paced_date(n))}" if post_date(n) else p['label']), t, a, 'Instagram feed (carousel), Instagram Story, Facebook, LinkedIn, X' + ('. 18+ only' if n == 9 else ''),
                     f"04_POSTS/{p['folder']}__{ 'STOP' if t == 'STOP-UNTIL' else ('GO-FALLBACK' if t == 'GO-WITH-FALLBACK' else 'GO') }", 'caption.txt in that folder', 'alt_text.txt in that folder', time_row(), unlock])
    return rows


CAL_HEAD = ['Order', 'Day', 'Status today', 'This post on its own', 'Platforms', 'Folder', 'Caption file', 'Alt-text file', 'Suggested time (default)', 'What unlocks it']


def write_calendar():
    rows = calendar()
    with open(ROOT / '01_POSTING_CALENDAR.csv', 'w', newline='', encoding='utf-8') as f:
        w = csv.writer(f); w.writerow(CAL_HEAD); w.writerows(rows)
    lp = ('post ' + str(STATE['last_posted'])) if STATE.get('last_posted') else 'none yet'
    head = (f"**Start gates:** {gates_text()}\n\n**Launch day:** {launch_text()}\n\n**Last post confirmed live:** {lp}. **Launch day (planned):** {fmt(STATE['start_date']) if STATE.get('start_date') else 'set when Megh says go'}.\n\n{dates_text()}\n\n"
            'One row per post, in the order they go out. **Instagram: all 12 go out on the launch day, in one sitting. Facebook, LinkedIn and X: one post a day, post 1 on the launch day (the Day column gives each date).** Nothing goes out until every row says GO or GO-FALLBACK under **Status today**: if any row says STOP-UNTIL, post nothing. '
            'On the launch day, work in rounds: the Instagram feed for posts 1 to 12 first, in order, so the grid forms at once; then Instagram Stories 1 to 12; then post 1 on Facebook, LinkedIn and X. Each day after, the next post on Facebook, LinkedIn and X, never two on one platform in a day. On every platform post n goes out only after post n-1 is live there. '
            'If a post fails, gets stuck or the app says to try again later, stop there: never skip a post, never retry many times, tell Megh. **Status today** is what you may do right now. **This post on its own** leaves out the start gates and the other 11 posts. '
            'Open the post folder named in the Folder column and read STATUS.txt there. After the 12, later posts are paced: Megh sends that plan.\n\n')
    md = ('# Posting calendar\n\n' + head + f"**Suggested time.** {DATA['time_note'].replace('default 7:30 to 9:30 pm India time', 'default ' + window())}\n\n"
          + '| ' + ' | '.join(CAL_HEAD) + ' |\n|' + '---|' * len(CAL_HEAD) + '\n' + '\n'.join('| ' + ' | '.join(c.replace('|', '/') for c in r) + ' |' for r in rows) + '\n')
    write_doc('01_POSTING_CALENDAR', md)


def write_held_index():
    L = ['# Held index', '', 'Every question that decides whether a post goes out. **Open** means nobody has said yes yet. **FYI** questions go to Anji and Harsha for information only and never hold a post. Each row names that person\'s one-page packet (a PDF in 05_HELD_INDEX_packets). Megh updates this when an owner replies.', '',
         '| ID | Post | Owner | Status | Question | If NO | What it blocks | Packet |', '|---|---|---|---|---|---|---|---|']
    for it in DATA['items']:
        on, ans = STATE.get('cleared_on', {}).get(it['id']), STATE['answers'].get(it['id'])
        st = ('CLEARED' + (f" {fmt(on)}" if on else '') + (f": {ans}" if ans else '')).replace('|', '/') if not is_open(it['id']) else ('ANSWERED NO' if it['id'] in STATE['rejected'] else ('FYI (does not hold)' if it.get('fyi') else ('OPEN (sign-off reported 28 Oct, scope unconfirmed)' if it.get('reported') else 'OPEN')))
        L.append(f"| {it['id']} | {it['post']} | {OWNER[it['owner']]['name']} | {st} | {it['q'].replace('|', '/')} | {it['no'].replace('|', '/')} | {blocks_text(it)} | {packet_link(it)} |")
    L += ['', 'The one-page questions for each person are the PDFs in 05_HELD_INDEX_packets. Megh forwards them; the team lead does not send them.']
    write_doc('05_HELD_INDEX', '\n'.join(L) + '\n')


# ---------- post folders
def find_folder(p):
    base = ROOT / '04_POSTS'
    for d in sorted(base.iterdir()):
        if d.is_dir() and d.name.startswith(p['folder'] + '__'):
            return d
    return None


def refresh_posts():
    for n in range(1, 13):
        p = POSTS[n]; t = status(n)
        suffix = {'STOP-UNTIL': 'STOP', 'GO-WITH-FALLBACK': 'GO-FALLBACK', 'GO': 'GO'}[t]
        d = find_folder(p); want = ROOT / '04_POSTS' / f"{p['folder']}__{suffix}"
        if d is None:
            raise SystemExit(f"folder for post {n} is missing: run make_kit.py first")
        if d != want:
            d.rename(want); d = want
        (d / 'STATUS.txt').write_text(status_text(n, d), encoding='utf-8')
        stop_file = d / '00_STOP_DO_NOT_POST.txt'
        if t == 'STOP-UNTIL':
            stop_file.write_text(f"STOP. Do not post anything from this folder.\nSee STATUS.txt for who is being waited on.\n", encoding='utf-8')
        elif stop_file.exists():
            stop_file.unlink()
        c, own = caption_for(n)
        if c is None:
            (d / 'caption.txt').write_text(withheld_text(n, own), encoding='utf-8')
            (d / 'caption_for_X.txt').write_text(withheld_text(n, own), encoding='utf-8')
        else:
            (d / 'caption.txt').write_text(c + '\n', encoding='utf-8')
            (d / 'caption_for_X.txt').write_text(short_for_x(c) + '\n', encoding='utf-8')
        (d / 'alt_text.txt').write_text(alt_text_for(n), encoding='utf-8')
        if 'paid' in p:
            pd = d / 'PAID_SAFE'
            held = [i for i in p['paid']['caption_held_by'] if is_open(i)] + [i['id'] for i in blockers(n, gates=False)]
            pdtxt = ('FOR ADS ONLY. Megh runs the ads. Do not post these pictures organically unless STATUS.txt says to use the fallback.\n\n'
                     + (('PAID CAPTION NOT RELEASED. Waiting on: ' + ', '.join(sorted(set(held))) + '.\n') if held else ('PAID-SAFE CAPTION:\n' + p['paid']['caption'] + '\n')))
            (pd / 'caption_paid_safe.txt').write_text(pdtxt, encoding='utf-8')
            L = ['PAID-SAFE ALT TEXT (only the pictures that differ from the normal ones):', '']
            for k, v in (p['paid']['alt'] or {}).items():
                L.append(('Story and wide: ' if k == 'compose' else f'Slide {k}: ') + v)
            (pd / 'alt_text_paid_safe.txt').write_text('\n'.join(L) + '\n', encoding='utf-8')


def make_zip():
    out = ROOT.parent / DATA['zip_name']
    root_name = pathlib.Path(DATA['zip_name']).stem
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
        for f in sorted(ROOT.rglob('*')):
            if f.is_file() and '__pycache__' not in f.parts and not f.name.startswith('.'):
                z.write(f, f'{root_name}/{f.relative_to(ROOT).as_posix()}')
    return out


def apply_args(a):
    def targets(tok):
        tok = str(tok)
        if tok.lower() == 'start': return [i['id'] for i in DATA['items'] if i['blocks']['kind'] == 'series']
        if tok.isdigit(): return [i['id'] for i in DATA['items'] if first_post(i) == int(tok) and i['blocks']['kind'] != 'series']
        if tok.upper() in ITEMS: return [tok.upper()]
        raise SystemExit(f"unknown target {tok}: use an item ID (K4), a post number (10) or 'start'")
    on = STATE.setdefault('cleared_on', {})  # the day each question was cleared (kept on a repeat clear; dropped on reject or reopen)
    today = datetime.date.today().isoformat()
    for tok in a.clear or []:
        for i in targets(tok):
            if i not in STATE['cleared']: STATE['cleared'].append(i)
            if i in STATE['rejected']: STATE['rejected'].remove(i)
            on.setdefault(i, today)
    for tok in a.reject or []:
        for i in targets(tok):
            if i not in STATE['rejected']: STATE['rejected'].append(i)
            if i in STATE['cleared']: STATE['cleared'].remove(i)
            on.pop(i, None)
    for tok in a.reopen or []:
        for i in targets(tok):
            for lst in (STATE['cleared'], STATE['rejected']):
                if i in lst: lst.remove(i)
            STATE['answers'].pop(i, None)
            on.pop(i, None)
    if a.posted is not None: STATE['last_posted'] = a.posted
    if a.start_date: datetime.date.fromisoformat(a.start_date); STATE['start_date'] = a.start_date
    if a.contact: STATE['contact'] = a.contact
    if a.team_lead: STATE['team_lead'] = a.team_lead
    if a.window: STATE['window'] = a.window
    if a.accounts: STATE['accounts'] = a.accounts
    if a.answer:
        i, v = a.answer[0].upper(), a.answer[1]
        if i not in ITEMS: raise SystemExit(f'unknown item {i}')
        STATE['answers'][i] = v
        if i not in STATE['cleared']: STATE['cleared'].append(i)
        if i in STATE['rejected']: STATE['rejected'].remove(i)
        on.setdefault(i, today)


def main():
    ap = argparse.ArgumentParser(description='Refresh the Nari 1 team kit.')
    ap.add_argument('--clear', nargs='+'); ap.add_argument('--reject', nargs='+'); ap.add_argument('--reopen', nargs='+')
    ap.add_argument('--answer', nargs=2, metavar=('ID', 'VALUE')); ap.add_argument('--status', action='store_true'); ap.add_argument('--no-zip', action='store_true')
    ap.add_argument('--posted', type=int); ap.add_argument('--start-date'); ap.add_argument('--contact'); ap.add_argument('--accounts'); ap.add_argument('--team-lead'); ap.add_argument('--window')
    a = ap.parse_args()
    apply_args(a)
    gate_ids = [i['id'] for i in DATA['items'] if i['blocks']['kind'] == 'series']
    if all(not is_open(g) for g in gate_ids):
        STATE.setdefault('gates_cleared_on', datetime.date.today().isoformat())
    else:
        STATE.pop('gates_cleared_on', None)
    STATE_FILE.write_text(json.dumps(STATE, indent=1, ensure_ascii=False), encoding='utf-8')
    for name, md in DATA['docs'].items():
        if name == '00_START_HERE':
            parts = md.split('\n', 2); md = parts[0] + '\n\n' + '\n'.join(now_block()) + '\n' + parts[2].lstrip('\n')
            md = md.replace('{{FIRST_JOB}}', first_job())
        md = md.replace('{{WINDOW}}', window()).replace('{{DATES}}', dates_text())
        write_doc(name, md)
    if not (ROOT / '07_POSTED_LOG.csv').exists():
        (ROOT / '07_POSTED_LOG.csv').write_text(DATA['posted_log_header'] + DATA['posted_log_example'], encoding='utf-8')
    if not (ROOT / '08_ENGAGEMENT_LOG.csv').exists():
        (ROOT / '08_ENGAGEMENT_LOG.csv').write_text(DATA['engagement_log_header'] + DATA['engagement_log_example'], encoding='utf-8')
    write_calendar(); write_held_index()
    if a.status:
        for n in range(1, 13): print(f"post {n:2d}  today {status(n):17s} on its own {status(n, gates=False)}")
        print('launch day:', launch_text())
        return
    refresh_posts()
    if not a.no_zip:
        z = make_zip(); print(f'zip: {z} ({z.stat().st_size // 1024} KB)')
    print('statuses:', ' '.join(f"{n}={status(n)[:2]}" for n in range(1, 13)), '| cleared:', ','.join(STATE['cleared']) or 'none')


if __name__ == '__main__':
    main()
